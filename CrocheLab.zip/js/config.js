window.APP_CONFIG = {
  geminiApiKey: "AQ.Ab8RN6L8IikCQXsqTaCm-1T2hTYPdseO6E-7P-TFFBGNzxkK1w",
  geminiModel: "gemini-3.5-flash-lite"
};
